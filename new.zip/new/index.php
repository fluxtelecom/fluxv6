<?php
include('conexao.php');
include('planos.php');

$cdrs_agrupados = array();
$fixos = ["Fixo LDN", "Fixo Local", "Especiais 4004", "0300"];
$moveis = ["Movel VC1", "Movel VC3", "Movel VC2", "Movel Local", "Celular VC2/VC3"];

$custos = [
        '0800' => 0,
        'Celular VC2/VC3' => 1.0,
        'Especiais' => 0,
        'Movel VC1' => 0.8,
        'Fixo Local' => 0.2,
        'Fixo LDN' => 0.4,
        'Movel Local' => 0.8,
        'Numero Especial' => 0,
        'Padrao' => 0,
];

if (isset($_GET['invoice_day'])) {
  $invoice_day = mysqli_real_escape_string($conn, $_GET['invoice_day']);
  $data_inicial = mysqli_real_escape_string($conn, $_GET['data_inicial']);
  $data_final = mysqli_real_escape_string($conn, $_GET['data_final']);

  $sqlCdr = mysqli_query($conn, "SELECT  
  accountid,
  flux.accounts.company_name as Empresa, 
  flux.pricelists.name as Plano,
  calltype,
  debit,
  sum(billseconds/60) AS Minutos,
  sum(debit) AS Custo,
  (SELECT COUNT(*) FROM flux.dids WHERE flux.accounts.id = flux.dids.accountid) AS quantidade
  from flux.cdrs INNER JOIN flux.accounts
  ON flux.cdrs.accountid = flux.accounts.id 
  INNER JOIN flux.pricelists ON flux.accounts.pricelist_id = flux.pricelists.id
  AND invoice_day = $invoice_day
  where callstart between '$data_inicial 00:00:00' and '$data_final 23:59:58'  
  and call_direction='outbound' 
  and calltype!='DID' 
  and billseconds > 0 
  group by accountid, provider_code_destination
  ORDER BY company_name ASC;
  ")
  or die(mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>cdrs</title>
  <meta charset="utf-8">
</head>
<body>
  <form>
  <td>Dia de fechamento</td><br>
    <input type="number" name="invoice_day">
    <input type="date" name="data_inicial">
    <input type="date" name="data_final">
    <input type="submit" value="OK">
  </form>
  <hr>
  <?php if (isset($sqlCdr)) { ?>
  <table border="1">
    <tr>
      <td>ID da conta</td>
      <td>Nome</td>
      <td>Plano</td>
      <td>Minutos usados por Tipo de ligacao</td>
      <td>Excedeu</td>
      <td>Minutos Total</td>
      <td>Valor excedente total</td>
      <td>Minutos Excedidos dentro do plano</td>
    </tr>
    <?php
    $cdrs = array();
    while ($dados = ($sqlCdr->fetch_array())) {
      array_push($cdrs, array(
        'accountid' => $dados['accountid'],
        'Empresa' => $dados['Empresa'],
	      'Plano' => $dados['Plano'],
        'calltype' => $dados['calltype'],
        'Minutos' => $dados['Minutos'],
        'Custo' => $dados['Custo'],
        'quantidade' => $dados['quantidade']
      ));
    }

    $cdrs_agrupados = array_reduce($cdrs, function ($resultado, $linha) {
      $id_conta = $linha['accountid'];

      $chamada = [
          'calltype' => $linha['calltype'],
          'Minutos' => $linha['Minutos'] 
      ];
    
      if (isset($resultado[$id_conta])) {
          $resultado[$id_conta]['Minutos Total'] += $linha['Minutos'];
          $resultado[$id_conta]['Custo Total'] += $linha['Custo'];
          $resultado[$id_conta]['quantidade'] = $linha['quantidade'];

          $encontrou_calltype = false;
          foreach ($resultado[$id_conta]['Tipo de ligacao'] as &$tipo_ligacao) {
              if ($tipo_ligacao['calltype'] === $linha['calltype']) {
                  $tipo_ligacao['Minutos'] += $linha['Minutos'];
                  $tipo_ligacao['Custo'] += $linha['Custo'];
                  $encontrou_calltype = true;
                  break;
              }
          }

          if (!$encontrou_calltype) {
              $resultado[$id_conta]['Tipo de ligacao'][] = $chamada;
          }
      } else {
          $resultado[$id_conta] = [
              'Nome' => $linha['Empresa'],
              'Plano' => $linha['Plano'],
              'Tipo de ligacao' => [$chamada],
              'Minutos Total' => $linha['Minutos'],
              'Custo Total' => $linha['Custo'],
              'quantidade' => $linha['quantidade']
          ];
      }
    
      return $resultado;
    }, []);
  }

  
    foreach ($cdrs_agrupados as $conta => $dados) {
    $minutos_excedente = 0;
    $minutos_excedente_total = 0;
    $excedeu = 'NÃO';
    $custo_excedentes = 0;
    
    
// Percorre todas as ligações e puxa tipo de ligação e quantitativo de minutos
foreach ($dados['Tipo de ligacao'] as $tipo_ligacao) {

    $chamada = $tipo_ligacao['calltype'];
    $minutos = $tipo_ligacao['Minutos'];
    // Verifica se o plano atual está presente no array de planos
    if (array_key_exists($dados['Plano'], $planos)) {
      //Verifica se a chamada existe dentro do plano
        if (array_key_exists($chamada, $planos[$dados['Plano']])) {
            $limite = $planos[$dados['Plano']][$chamada];
            $limite *= $dados['quantidade'];
            //verifica se excedeu o limite de 
            if ($minutos > $limite){
                $excedeu = 'SIM';
                $minutos_excedente = $minutos - $limite;
                $minutos_excedente_total += $minutos_excedente;
                $valor = $custos[$chamada];
                $custo_excedentes += ($minutos_excedente * $valor);
            }
        }
    }
  }
  
?>

  <tr>
    <td><?php echo $conta; ?></td>
    <td><?php echo $dados['Nome'];?> - (<?php echo $dados['quantidade']?>) DID(s)</td>
    <td><?php echo $dados['Plano']; ?></td>
    <td>
        <?php foreach ($dados['Tipo de ligacao'] as $tipo_ligacao) { ?>
            <p><?php echo $tipo_ligacao['calltype']; ?>: <?php echo round(($tipo_ligacao['Minutos']), 2); ?> min</p>
        <?php } ?>
    </td>
    <td><?php echo $excedeu; ?></td>
    <td><?php echo round($dados['Minutos Total'], 2); ?> min</td>
    <td>R$ <?php echo number_format($custo_excedentes, 2, ',', '.'); ?></td>
    <td><?php echo round($minutos_excedente_total, 2); ?> min</td>
</tr>
<?php } ?>
</table>
</body>
</html>