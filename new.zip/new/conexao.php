<?php
$servername = "127.0.0.1:3306";
$database = "flux";
$username = "fluxuser";
$password = "DA4x*lfG6ifz3SKT98Op";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
